function c=Ps(EVI,EVIopt,LSWI)

          if  EVI>EVIopt
                    fPscaled=1;
                else if EVIsite<0.2&EVI>0
                        fPscaled=(1+LSWI)/4;
                    else if EVI==0|EVI<0
                            fPscaled=0;
                        else
                            fPscaled=(1+LSWI)/2;
                        end
                    end
          end

 