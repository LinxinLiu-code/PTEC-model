function fT=Ts(T,Topt)
               T1=0.8+0.02*Topt-0.0005*Topt^2;
            T2=1.184*(1+exp(0.3*(-Topt-10+T)))./(1+exp(0.2*(Topt-10-T)));
            fT=T1.*T2;
            fT(fT>1)=1;
            fT(fT<0)=0;
