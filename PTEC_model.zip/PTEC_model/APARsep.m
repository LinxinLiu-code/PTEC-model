function [APARsh,APARsu]=APARsep(PARdir,PARdif,PARdifu,LAI,LAIsu,LAIsh,C,csita)

APARsh=(((PARdif-PARdifu)./LAI)+C).*LAIsh; 
APARsu=(((PARdir*cos(pi/3)./csita+(PARdif-PARdifu))./LAI)+C).*LAIsu;  
