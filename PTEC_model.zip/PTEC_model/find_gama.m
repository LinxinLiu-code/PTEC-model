function [gama]=find_gama(landcover)  
switch landcover
    case 1
        gama=0.6;
    case 2
        gama=0.8;
    case 3
        gama=0.6;
     case 4
        gama=0.8;
     case 5
        gama=0.7;
     case 6
        gama=0.5;
     case 7
        gama=0.5;
     case 8
        gama=0.8;
     case 9
        gama=0.8;
     case 10
        gama=0.9;
     case 11
        gama=0.9;
     case 12
        gama=0.9;
     case 13
        gama=0;
     case 14
        gama=0;
     case 15
        gama=0;
     case 16
        gama=0;
     case 0
        gama=0;
end

