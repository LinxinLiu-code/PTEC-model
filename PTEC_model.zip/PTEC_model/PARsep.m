function [PARdif,PARdir,PARdifu,C]=PARsep(PAR,PARdiff,gama,LAI,csita)

      PARdif=double(PARdiff(ii,jj))*0.0864;      % unit conversion
      PARdir=double(PAR(ii,jj))*0.0864-PARdif;
      PARdifu=PARdif.*exp(-0.5*gama*LAI./(0.537+0.025*LAI)); 
      C=0.07*gama*PARdir.*(1.1-0.1*LAI).*exp(-csita);
end