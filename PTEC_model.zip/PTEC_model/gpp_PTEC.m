%% the PTEC model (in " Advancing global terrestrial primary productivity prediction via remote sensing with explicit consideration of plant phenology and water constraints")
 %% constants
LUE_msu=1.32;
LUE_msh=3.02;
BeginYear=2001;
EndYear=2021;
rows=3000;
columns=7200;
pi=3.1415926;
%% calculating
for year=BeginYear:EndYear
  
    for  day=1:365
     %% input meteorological data, land surface product,landcover and et al. ( T,Topt, LSWI,LSWImaxY,EVI,EVIoptY,PAR,PARdiff, LAI, LandCover ,latitude)
        
        for i=1:rows
  
            for j=1:columns
             %% clumping index by different vegetation types
               [gama] = find_gama(landcover(i,j));
             %% cosine of solar elevation angle
               [csita]=cita(day,latitude(i,j))
               
              %% separate sunlit/shaded leaves
                [LAIsu,LAIsh]=LAIsep(gama,LAI(i,j),csita );
                [PARdir,PARdif,PARdifu,C]=PARsep(PAR(i,j),PARdiff(i,j),gama,LAI(i,j));
                [APARsu,APARsh]=APARsep(PARdir,PARdif,PARdifu,LAI(i,j),LAIsu,LAIsh,C,csita );
                
               %% temperatere scalar 
                 f_T=Ts(T(i,j),Topt(i,j));
                
                %% water scalar
                 f_W=Ws(LSWI(i,j),LSWImax(i,j));
                
                %% phenology scalar
                 f_P=Ps(EVI(i,j),EVIopt(i,j),LSWI(i,j));
                
                %% calculate GPPs
                GPP_sun(i,j) = LUE_msu*APARsu*f_T*f_W*f_P;
                GPP_shade(i,j) = LUE_msh*APARsh*f_T*f_W*f_P;
                GPP(i,j) = GPP_sun(i,j) + GPP_shade(i,j);
                
            end
        end
     %% output GPP products(annual, monthly, 8-day) .For example, the following:
        if ( day==(floor( day/8)*8)|| day==365)
            day=floor(( day-1)/8)*8+1;
            geotiffwrite(outputPath,int16(GPP_8day*100),R);
            geotiffwrite(outputPath,int16(SunGPP_8day*100),R);
            geotiffwrite(outputPath,int16(ShadeGPP_8day*100),R);         
        end
   end
end