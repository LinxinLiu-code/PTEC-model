function csita=cita(day,lat)
 

    if mod(day,4)==0
        zz=(-23.45*cos(360/366*(day+10)/180*pi))/180*pi;
    else
        zz=(-23.45*cos(360/365*(day+10)/180*pi))/180*pi;
    end
    lat_pi=latT/180*pi;
   csita=sin(lat_pi).*sin(zz)+cos(lat_pi).*cos(zz);
