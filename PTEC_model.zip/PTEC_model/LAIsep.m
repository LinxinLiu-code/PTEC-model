function [LAIsu,LAIshade]=LAIsep(gama,LAI,csita)
LAIsu=2*csita.*(1-exp(-0.5*gama.*LAI./csita)); 
%计算阴叶叶面积指数
LAIsh=LAI-LAIsu; 